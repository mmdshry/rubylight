module.exports = {
  apps: [
    {
      name: 'rubylight-tala-proxy',
      script: 'server/tala-proxy.mjs',
      cwd: '/home/rubylight/public_html/rubylight',
      instances: 1,
      exec_mode: 'fork',
      env: {
        NODE_ENV: 'production',
        HOST: '127.0.0.1',
        PORT: 3009,
      },
      max_memory_restart: '150M',
    },
  ],
}
