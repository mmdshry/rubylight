import http from 'node:http'
import { setTimeout as sleep } from 'node:timers/promises'

const HOST = process.env.HOST || '127.0.0.1'
const PORT = Number(process.env.PORT || 3009)
const CACHE_MS = Number(process.env.TALA_CACHE_MS || 60_000)
const UA =
  'Mozilla/5.0 (compatible; RubyLightTalaProxy/1.0; +https://rubylight.ir)'

let cache = { at: 0, body: null }

function parsePrice(raw) {
  if (typeof raw === 'number' && Number.isFinite(raw)) return raw
  if (typeof raw !== 'string') return null
  const n = Number(raw.replace(/,/g, '').trim())
  return Number.isFinite(n) ? n : null
}

async function fetchJson(url) {
  const res = await fetch(url, {
    headers: { Accept: 'application/json', 'User-Agent': UA },
    signal: AbortSignal.timeout(12_000),
  })
  if (!res.ok) throw new Error(`${url} → ${res.status}`)
  return res.json()
}

async function fromAmirhossein() {
  const rows = await fetchJson('https://tgju.amirhossein.info/api/price/gold')
  if (!Array.isArray(rows)) throw new Error('unexpected gold payload')
  const data = {}
  for (const group of rows) {
    for (const item of group.prices || []) {
      const key = String(item.key || '').toLowerCase()
      const price = parsePrice(item.price)
      if (!key || price === null) continue
      if (key === 'geram18' || key === 'mesghal' || key === 'geram24') {
        data[key] = price
      }
      if (key.includes('emami') || key === 'sekee') data.emami = price
    }
  }
  if (!data.geram18 && !data.mesghal) throw new Error('no gold keys')
  return data
}

async function fromTgjuAjax() {
  const json = await fetchJson('https://call2.tgju.org/ajax.json')
  const current = json?.current || {}
  const pick = (...keys) => {
    for (const k of keys) {
      const n = parsePrice(current[k]?.p)
      if (n !== null) return n
    }
    return null
  }
  const data = {
    geram18: pick('geram18'),
    mesghal: pick('mesghal'),
    geram24: pick('geram24'),
    emami: pick('sekee', 'price_dollar_rl'),
  }
  for (const k of Object.keys(data)) {
    if (data[k] === null) delete data[k]
  }
  if (!data.geram18 && !data.mesghal) throw new Error('ajax empty')
  return data
}

async function loadQuotes() {
  const now = Date.now()
  if (cache.body && now - cache.at < CACHE_MS) return cache.body

  let data
  let source = 'amirhossein'
  try {
    data = await fromAmirhossein()
  } catch {
    source = 'tgju-ajax'
    data = await fromTgjuAjax()
  }

  const body = {
    ok: true,
    source,
    updatedAt: new Date().toISOString(),
    data,
  }
  cache = { at: now, body }
  return body
}

function send(res, status, payload) {
  const json = JSON.stringify(payload)
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'public, max-age=30',
    'Access-Control-Allow-Origin': '*',
  })
  res.end(json)
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url || '/', `http://${HOST}:${PORT}`)
  const method = req.method || 'GET'
  const isRead = method === 'GET' || method === 'HEAD'

  if (isRead && (url.pathname === '/api/tala' || url.pathname === '/api/tala/')) {
    try {
      const body = await loadQuotes()
      if (method === 'HEAD') {
        res.writeHead(200, {
          'Content-Type': 'application/json; charset=utf-8',
          'Cache-Control': 'public, max-age=30',
          'Access-Control-Allow-Origin': '*',
        })
        res.end()
        return
      }
      send(res, 200, body)
    } catch (err) {
      send(res, 502, {
        ok: false,
        error: err instanceof Error ? err.message : 'fetch failed',
      })
    }
    return
  }
  if (isRead && url.pathname === '/health') {
    if (method === 'HEAD') {
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' })
      res.end()
      return
    }
    send(res, 200, { ok: true, port: PORT })
    return
  }
  send(res, 404, { ok: false, error: 'not found' })
})

server.listen(PORT, HOST, () => {
  console.log(`[tala-proxy] listening on http://${HOST}:${PORT}`)
})

server.on('error', (err) => {
  console.error('[tala-proxy] listen error', err)
  process.exit(1)
})

// warm cache once (non-blocking)
void loadQuotes().catch(async (err) => {
  console.warn('[tala-proxy] warm failed', err.message)
  await sleep(1000)
})
